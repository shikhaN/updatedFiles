package com.company.service;

import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.UserTaskService;
import org.jbpm.services.api.model.UserTaskInstanceDesc;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.model.Status;
import org.kie.api.task.model.TaskSummary;
import org.kie.internal.query.QueryFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * @author Shikha
 *
 */
@SpringBootApplication
@RestController
public class Application  {

	@Autowired
	private ProcessService processService;
	@Autowired
	private RuntimeDataService runtimeDataService;
	@Autowired
	private UserTaskService userTaskService;
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	/**
	 * @param taskOwner
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/initiateProcess")
	public ResponseEntity<String> initiateWorkflowProcess(@RequestParam String taskOwner) throws Exception {


		// Provided as an example. Not actually needed by our process.
		Map<String, Object> vars = new HashMap<>();
		vars.put("processVar1", "Minerva");
		vars.put("taskOwner", taskOwner);

		Long processInstanceId = processService.startProcess("business-application-kjar-1.0-SNAPSHOT", "com.minerva.Demo", vars);

		return ResponseEntity.status(HttpStatus.CREATED).body("Task Initiated with processId=!"+processInstanceId);
	}

	/**
	 * @param processId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/humanTaskId")
	public ResponseEntity<String> humanTaskIdByProcessId(@RequestParam Long processId) throws Exception {

		List<Long> taskLists = runtimeDataService.getTasksByProcessInstanceId(processId);


		Long taskId = runtimeDataService.getTaskById(taskLists.get(0)).getTaskId();




		return ResponseEntity.status(HttpStatus.FOUND).body("Next Task Id is: "+taskId);
	}

	/**
	 * @param processId
	 * @param taskId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/humanTaskDetails")
	public ResponseEntity<String> humanTaskDetails( @RequestParam Long processId, @RequestParam Long taskId) throws Exception {



		List<Long> taskLists = runtimeDataService.getTasksByProcessInstanceId(processId);

		UserTaskInstanceDesc userTaskDetails = runtimeDataService.getTaskById(taskId);

		String taskOwner=userTaskDetails.getActualOwner();
		String ustatus=userTaskDetails.getStatus();

		String returnstatus="Not yet Claimed";
		if(taskOwner==null && ustatus==Status.Ready.name().toString())
			returnstatus="Not yet Claimed";
		if(taskOwner!=null)
			returnstatus="Task Claimed by user:"+taskOwner;
		if(taskOwner!=null && ustatus==Status.InProgress.name().toString())
			returnstatus="Task In Progress by user:"+taskOwner;
		if(taskOwner!=null && ustatus==Status.Completed.name().toString())
			returnstatus="Task In Completed by user:"+taskOwner;

		return ResponseEntity.status(HttpStatus.ACCEPTED).body("Task Status is : "+returnstatus);
	}

	/**
	 * @param vstatus
	 * @param processId
	 * @param taskId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/humanTaskAction")
	public ResponseEntity<String> humanTaskAction(@RequestParam String vstatus, @RequestParam Long processId, @RequestParam Long taskId) throws Exception {



		List<Long> taskLists = runtimeDataService.getTasksByProcessInstanceId(processId);

		UserTaskInstanceDesc userTaskDetails = runtimeDataService.getTaskById(taskId);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("status", vstatus);

		String taskOwner=userTaskDetails.getActualOwner();
		List<TaskSummary> taskSummaries = runtimeDataService.getTasksAssignedAsPotentialOwner(taskOwner, new QueryFilter());

		taskSummaries.forEach(s->{
			Status status = taskSummaries.get(0).getStatus();
			if ( status == Status.Ready )
				userTaskService.claim(s.getId(), taskOwner);
			userTaskService.start(s.getId(), taskOwner);
			userTaskService.complete(s.getId(), taskOwner, params);
		});


		return ResponseEntity.status(HttpStatus.OK).body("Task Completed Successfully with Owner: "+taskOwner);
	}

	/**
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/userTaskDetails")
	public ResponseEntity<List<TaskSummary>> userTaskDetails(@RequestParam String userId) throws Exception {


		List<TaskSummary> userTaskDetails = runtimeDataService.getTasksAssignedAsPotentialOwner(userId, new QueryFilter());


		return ResponseEntity.status(HttpStatus.ACCEPTED).body(userTaskDetails);
	}

}